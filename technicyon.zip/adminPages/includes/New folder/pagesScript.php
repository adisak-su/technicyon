<script src="../../plugins/jquery/jquery.min.js"></script>
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../../plugins/sweetalert2/dist/sweetalert2.min.js"></script>
<script src="../../plugins/bootstrap-toggle/bootstrap-toggle.min.js"></script>
<script src="../../plugins/toastr/toastr.min.js"></script>
<script src="../../assets/js/adminlte.js"></script>

<script src="../../assets/js/common.js"></script> // for menu all pages
<!-- <script src="../../assets/js/adminlte.min.js"></script> -->