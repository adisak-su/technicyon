<?php
// $max_width = 100;
// $master_size = 150;

// $dirImages = "images_150/";
// $masterFile = $dirImages . "Master_150.jpg";

// // Size 150
// $max_width = 110;
// $master_size = 150;
// $fontSizeText = 40;
// $spaceWidth = 10;

// // Size 250
// $max_width = 180;
// $master_size = 250;
// $fontSizeText = 60;
// $spaceWidth = 20;

// // Size 500
// $max_width = 360;
// $master_size = 500;
// $fontSizeText = 100;
// $spaceWidth = 40;

// $dirImages = "images_" . $master_size . "/";
// $masterFile = $dirImages . "Master_" . $master_size . ".jpg";

$dirImages = "images/";
$masterFile = $dirImages . "Master.jpg";

// // Size 500
$max_width = 360;
$master_size = 500;
$fontSizeText = 100;
$spaceWidth = 40;

// Size 250
$max_width = 180;
$master_size = 250;
$fontSizeText = 60;
$spaceWidth = 20;

$dirImages = "images/";
$masterFile = $dirImages . "Master_" . $master_size . ".jpg";

?>