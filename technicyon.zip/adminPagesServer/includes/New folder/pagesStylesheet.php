<link rel="stylesheet" href="../../plugins/@sweetalert2/theme-bootstrap-4/bootstrap-4.css">
<link rel="stylesheet" href="../../plugins/bootstrap-toggle/bootstrap-toggle.min.css">
<link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="../../plugins/toastr/toastr.min.css">
<link rel="stylesheet" href="../../assets/css/adminlte.css?<?php echo time(); ?>">
<link rel="stylesheet" href="../../assets/css/style.css">