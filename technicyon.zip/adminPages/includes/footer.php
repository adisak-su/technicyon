
    <!-- Main Footer -->
    <footer class="main-footer layout-*-footer-fixed text-center">
        <strong>Copyright &copy; Adisak Supatanasinkasem 2022.</strong>
    </footer>
